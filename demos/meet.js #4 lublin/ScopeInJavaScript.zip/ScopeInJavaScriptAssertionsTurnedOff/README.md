# AdvancedJavaScript
Materials for presentation "Scope in javaScript– potential traps for people new in javaScript"

How to set it up:
install node from https://nodejs.org/en/download/

npm install -g bower

npm install -g tsd

bower install
tsd install
