Materials for presentation "Scope w JavaScript – pułapki dla osób przechodzących z innych języków"

How to set it up:
install node from https://nodejs.org/en/download/

npm install -g bower

npm install -g tsd

bower install
tsd install